# NOVA Android — MVP 1.1

This is the Android source project for NOVA, plus a GitHub Actions workflow that can build a debug APK in the cloud.

## Build without a computer
1. Create a GitHub repository from the files in this project and upload the contents of this folder (not the outer folder).
2. Open the repository's **Actions** tab.
3. Run **Build NOVA APK** (or wait for the build after pushing to `main`).
4. Open the successful workflow run, download the `NOVA-debug-apk` artifact, unzip it, and install `app-debug.apk` on your phone.

The workflow is a convenience; it has not been run from this environment. A successful workflow run is required before the APK exists.

## Features in this MVP
- Black-and-white UI with pale ice-blue accents.
- Russian speech recognition after tapping the microphone.
- Android text-to-speech responses.
- Local memory stored on-device.
- Commands: remember a fact, read memory count, swipe up, back, lock screen, volume up/down, open YouTube, open Settings.

## Limitations
- No always-on wake word ("NOVA").
- No connected cloud AI/chat model.
- Speech recognition depends on an installed Android speech recognition service and network/device settings.
- Back, swipe, and lock-screen commands require manually enabling NOVA under Android Accessibility settings.
- Accessibility service does not read screen contents.
- This project has not been built or tested on a physical OnePlus device in this environment.

Minimum Android: 8.0 (API 26). Compile/target SDK: 35.
