package com.nova.assistant

import android.content.Context

/** Простая локальная память MVP. Данные остаются в SharedPreferences на устройстве. */
class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("nova_memory", Context.MODE_PRIVATE)

    fun add(text: String) {
        val old = all()
        val updated = (old + text.trim()).distinct().takeLast(100)
        prefs.edit().putStringSet("items", updated.toSet()).apply()
    }

    fun all(): List<String> = prefs.getStringSet("items", emptySet())
        ?.toList()?.sorted() ?: emptyList()

    fun clear() { prefs.edit().remove("items").apply() }
}
