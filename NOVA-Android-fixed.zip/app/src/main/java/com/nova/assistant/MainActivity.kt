package com.nova.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Black = Color(0xFF08090B)
private val Panel = Color(0xFF15171A)
private val White = Color(0xFFF4F5F6)
private val Ice = Color(0xFFB9E8F5)
private val Muted = Color(0xFF92999F)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var memory: MemoryStore
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onResult: ((String) -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening()
        else onResult?.invoke("Без разрешения на микрофон я не могу услышать команду.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        memory = MemoryStore(this)
        tts = TextToSpeech(this, this)
        setContent {
            var transcript by remember { mutableStateOf("Я слушаю, когда ты нажмёшь микрофон.") }
            var memories by remember { mutableStateOf(memory.all()) }
            var showMemory by remember { mutableStateOf(false) }
            var listening by remember { mutableStateOf(false) }
            SideEffect { onResult = { transcript = it; listening = false } }

            MaterialTheme(colorScheme = darkColorScheme(
                background = Black, surface = Panel, primary = Ice,
                onBackground = White, onSurface = White
            )) {
                Surface(Modifier.fillMaxSize(), color = Black) {
                    Column(
                        Modifier.fillMaxSize().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("N O V A", color = White, fontSize = 25.sp, fontWeight = FontWeight.Light)
                                Text("PERSONAL ASSISTANT  •  v1.0", color = Muted, fontSize = 9.sp)
                            }
                            IconButton(onClick = {
                                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            }) { Icon(Icons.Default.Settings, "Настройки", tint = Muted) }
                            IconButton(onClick = { showMemory = !showMemory; memories = memory.all() }) {
                                Icon(Icons.Default.Memory, "Память", tint = Ice)
                            }
                        }
                        Spacer(Modifier.height(52.dp))
                        Box(
                            Modifier.size(190.dp).background(Color(0xFF101316), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(Modifier.size(150.dp).background(Color(0xFF20262A), CircleShape),
                                contentAlignment = Alignment.Center) {
                                Box(Modifier.size(118.dp).background(Ice.copy(alpha = 0.10f), CircleShape),
                                    contentAlignment = Alignment.Center) {
                                    Text("N", color = White, fontSize = 58.sp, fontWeight = FontWeight.ExtraLight)
                                }
                            }
                        }
                        Spacer(Modifier.height(28.dp))
                        Text(if (listening) "СЛУШАЮ" else "ГОТОВА К РАБОТЕ",
                            color = Ice, fontSize = 11.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(12.dp))
                        Text(transcript, color = White, fontSize = 16.sp)
                        Spacer(Modifier.height(24.dp))
                        Button(
                            onClick = {
                                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                                    == PackageManager.PERMISSION_GRANTED) startListening()
                                else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                listening = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black),
                            shape = RoundedCornerShape(30.dp),
                            modifier = Modifier.fillMaxWidth().height(54.dp)
                        ) {
                            Icon(Icons.Default.Mic, null)
                            Spacer(Modifier.width(9.dp))
                            Text("ГОВОРИТЬ С NOVA", fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Ice)
                        ) { Text("НАСТРОИТЬ УПРАВЛЕНИЕ ТЕЛЕФОНОМ") }

                        if (showMemory) {
                            Spacer(Modifier.height(20.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("ЛОКАЛЬНАЯ ПАМЯТЬ", color = Ice, modifier = Modifier.weight(1f))
                                TextButton(onClick = { memory.clear(); memories = emptyList() }) {
                                    Text("Очистить", color = Muted)
                                }
                            }
                            LazyColumn(Modifier.weight(1f, fill = false)) {
                                items(memories) { item ->
                                    Text("•  $item", color = White, modifier = Modifier.padding(vertical = 5.dp))
                                }
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        Text("BLACK  /  WHITE  /  A TOUCH OF ICE", color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onResult?.invoke("На устройстве нет доступного сервиса распознавания речи.")
            speak("На устройстве нет доступного сервиса распознавания речи.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onError(error: Int) { onResult?.invoke("Не удалось распознать речь. Попробуй ещё раз.") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isBlank()) {
                    onResult?.invoke("Я не расслышала. Попробуй ещё раз.")
                } else {
                    onResult?.invoke(text)
                    handleCommand(text)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажите команду для NOVA")
        }
        speechRecognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale("ru", "RU")).trim()
        when {
            command.startsWith("запомни ") -> {
                val fact = raw.trim().substringAfter(" ", "").trim()
                if (fact.isNotBlank()) { memory.add(fact); speak("Запомнила.") }
            }
            command.contains("что ты помнишь") || command.contains("моя память") -> {
                val facts = memory.all()
                speak(if (facts.isEmpty()) "Пока память пуста." else "Я помню ${facts.size} фактов. Открой раздел памяти, чтобы посмотреть их.")
            }
            command.contains("листай дальше") || command.contains("следующее видео") || command.contains("прокрути") -> {
                val ok = NOVAAccessibilityService.instance?.swipeUp() ?: false
                speak(if (ok) "Хорошо." else "Сначала включи службу управления NOVA в настройках специальных возможностей.")
            }
            command.contains("назад") -> {
                val ok = NOVAAccessibilityService.instance
                if (ok != null) { ok.goBack(); speak("Возвращаюсь.") }
                else speak("Сначала включи службу управления NOVA.")
            }
            command.contains("заблокируй экран") || command.contains("выключи экран") -> {
                val ok = NOVAAccessibilityService.instance?.lockScreen() ?: false
                speak(if (ok) "Блокирую экран." else "Для блокировки включи службу NOVA в настройках специальных возможностей.")
            }
            command.contains("громче") || command.contains("прибавь звук") -> {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                speak("Сделала громче.")
            }
            command.contains("тише") || command.contains("убавь звук") -> {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                speak("Сделала тише.")
            }
            command.contains("открой youtube") || command.contains("открой ютуб") -> {
                val launch = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (launch != null) { startActivity(launch); speak("Открываю YouTube.") }
                else speak("YouTube не найден.")
            }
            command.contains("открой настройки") -> {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                speak("Открываю настройки.")
            }
            command.isNotBlank() -> speak("Я услышала: $raw. Пока не знаю такую команду.")
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova-utterance")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
